package com.quang.chieutv

import android.content.Context
import android.net.Uri
import fi.iki.elonen.NanoHTTPD
import java.io.InputStream

/**
 * Máy chủ web nhỏ chạy trên điện thoại. TV LG sẽ tải ảnh/video từ đây qua Wi-Fi.
 * Hỗ trợ "Range" để TV tua video được.
 */
class MediaServer(private val context: Context, port: Int) : NanoHTTPD(port) {

    @Volatile var currentUri: Uri? = null
    @Volatile var currentMime: String = "application/octet-stream"

    override fun serve(session: IHTTPSession): Response {
        val uri = currentUri ?: return newFixedLengthResponse(
            Response.Status.NOT_FOUND, MIME_PLAINTEXT, "Chưa chọn file"
        )
        return try {
            val total = fileSize(uri)
            val range = session.headers["range"]
            val resp: Response
            if (range != null && range.startsWith("bytes=") && total > 0) {
                val parts = range.removePrefix("bytes=").split("-")
                val start = parts[0].toLongOrNull() ?: 0L
                val end = parts.getOrNull(1)?.toLongOrNull()?.coerceAtMost(total - 1) ?: (total - 1)
                if (start >= total) {
                    resp = newFixedLengthResponse(
                        Response.Status.RANGE_NOT_SATISFIABLE, MIME_PLAINTEXT, ""
                    )
                    resp.addHeader("Content-Range", "bytes */$total")
                    return resp
                }
                val len = end - start + 1
                val input = open(uri)
                skipFully(input, start)
                resp = newFixedLengthResponse(Response.Status.PARTIAL_CONTENT, currentMime, input, len)
                resp.addHeader("Content-Range", "bytes $start-$end/$total")
            } else {
                val input = open(uri)
                resp = if (total > 0)
                    newFixedLengthResponse(Response.Status.OK, currentMime, input, total)
                else
                    newChunkedResponse(Response.Status.OK, currentMime, input)
            }
            resp.addHeader("Accept-Ranges", "bytes")
            resp.addHeader("contentFeatures.dlna.org", Dlna.dlnaFeatures(currentMime))
            resp.addHeader(
                "transferMode.dlna.org",
                if (currentMime.startsWith("image")) "Interactive" else "Streaming"
            )
            resp
        } catch (e: Exception) {
            newFixedLengthResponse(Response.Status.INTERNAL_ERROR, MIME_PLAINTEXT, e.message ?: "lỗi")
        }
    }

    private fun open(uri: Uri): InputStream =
        context.contentResolver.openInputStream(uri) ?: throw IllegalStateException("Không mở được file")

    private fun fileSize(uri: Uri): Long = try {
        context.contentResolver.openAssetFileDescriptor(uri, "r")?.use { it.length } ?: -1L
    } catch (e: Exception) { -1L }

    private fun skipFully(input: InputStream, n: Long) {
        var left = n
        while (left > 0) {
            val s = input.skip(left)
            if (s <= 0) { if (input.read() == -1) return; left-- } else left -= s
        }
    }
}
