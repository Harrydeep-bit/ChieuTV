package com.quang.chieutv

import org.w3c.dom.Element
import java.io.ByteArrayInputStream
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.HttpURLConnection
import java.net.InetAddress
import java.net.SocketTimeoutException
import java.net.URL
import javax.xml.parsers.DocumentBuilderFactory

/** Một TV (hoặc thiết bị) nhận được hình qua DLNA. */
data class Tv(val name: String, val controlUrl: String) {
    override fun toString() = name
}

/** Tìm TV trong mạng Wi-Fi và điều khiển nó bằng giao thức DLNA/UPnP. */
object Dlna {

    private const val AVT = "urn:schemas-upnp-org:service:AVTransport:1"

    /** Gửi tín hiệu tìm kiếm ra mạng, chờ vài giây xem TV nào trả lời. */
    fun discover(timeoutMs: Int = 4000): List<Tv> {
        val locations = linkedSetOf<String>()
        val msg = ("M-SEARCH * HTTP/1.1\r\n" +
                "HOST: 239.255.255.250:1900\r\n" +
                "MAN: \"ssdp:discover\"\r\n" +
                "MX: 3\r\n" +
                "ST: $AVT\r\n\r\n").toByteArray()
        DatagramSocket().use { sock ->
            sock.soTimeout = 800
            val group = InetAddress.getByName("239.255.255.250")
            repeat(3) { sock.send(DatagramPacket(msg, msg.size, group, 1900)) }
            val end = System.currentTimeMillis() + timeoutMs
            val buf = ByteArray(4096)
            while (System.currentTimeMillis() < end) {
                try {
                    val p = DatagramPacket(buf, buf.size)
                    sock.receive(p)
                    val text = String(p.data, 0, p.length)
                    text.lines().firstOrNull { it.startsWith("LOCATION:", true) }
                        ?.substringAfter(":")?.trim()?.let { locations.add(it) }
                } catch (_: SocketTimeoutException) { }
            }
        }
        return locations.mapNotNull { runCatching { describe(it) }.getOrNull() }
            .distinctBy { it.controlUrl }
    }

    /** Đọc mô tả thiết bị để lấy tên TV và địa chỉ điều khiển. */
    private fun describe(location: String): Tv? {
        val xml = URL(location).openConnection().apply {
            connectTimeout = 3000; readTimeout = 3000
        }.getInputStream().use { it.readBytes() }
        val doc = DocumentBuilderFactory.newInstance().apply { isNamespaceAware = false }
            .newDocumentBuilder().parse(ByteArrayInputStream(xml))
        val name = doc.getElementsByTagName("friendlyName").item(0)?.textContent ?: "TV"
        val base = doc.getElementsByTagName("URLBase").item(0)?.textContent?.takeIf { it.isNotBlank() }
            ?: location
        val services = doc.getElementsByTagName("service")
        for (i in 0 until services.length) {
            val s = services.item(i) as Element
            val type = s.getElementsByTagName("serviceType").item(0)?.textContent ?: continue
            if (type.contains("AVTransport")) {
                val ctrl = s.getElementsByTagName("controlURL").item(0)?.textContent ?: continue
                return Tv(name.trim(), URL(URL(base), ctrl.trim()).toString())
            }
        }
        return null
    }

    fun dlnaFeatures(mime: String): String {
        val pn = when {
            mime == "image/jpeg" -> "DLNA.ORG_PN=JPEG_LRG;"
            mime == "image/png" -> "DLNA.ORG_PN=PNG_LRG;"
            else -> ""
        }
        return "${pn}DLNA.ORG_OP=01;DLNA.ORG_CI=0;DLNA.ORG_FLAGS=01700000000000000000000000000000"
    }

    private fun esc(s: String) = s.replace("&", "&amp;").replace("<", "&lt;")
        .replace(">", "&gt;").replace("\"", "&quot;")

    private fun soap(tv: Tv, action: String, args: String) {
        val body = """<?xml version="1.0" encoding="utf-8"?>
<s:Envelope xmlns:s="http://schemas.xmlsoap.org/soap/envelope/" s:encodingStyle="http://schemas.xmlsoap.org/soap/encoding/">
<s:Body><u:$action xmlns:u="$AVT"><InstanceID>0</InstanceID>$args</u:$action></s:Body>
</s:Envelope>""".toByteArray(Charsets.UTF_8)
        val c = URL(tv.controlUrl).openConnection() as HttpURLConnection
        c.connectTimeout = 4000; c.readTimeout = 6000
        c.requestMethod = "POST"
        c.doOutput = true
        c.setRequestProperty("Content-Type", "text/xml; charset=\"utf-8\"")
        c.setRequestProperty("SOAPAction", "\"$AVT#$action\"")
        c.outputStream.use { it.write(body) }
        val code = c.responseCode
        if (code !in 200..299) {
            val err = c.errorStream?.use { String(it.readBytes()) } ?: ""
            val detail = Regex("<errorDescription>(.*?)</errorDescription>").find(err)?.groupValues?.get(1)
            throw RuntimeException("TV báo lỗi $code ${detail ?: ""}".trim())
        }
        c.inputStream.close()
    }

    /** Gửi đường dẫn ảnh/video cho TV rồi bấm phát. */
    fun play(tv: Tv, url: String, mime: String, title: String) {
        val cls = when {
            mime.startsWith("image") -> "object.item.imageItem.photo"
            mime.startsWith("video") -> "object.item.videoItem"
            else -> "object.item.audioItem.musicTrack"
        }
        val didl = "<DIDL-Lite xmlns=\"urn:schemas-upnp-org:metadata-1-0/DIDL-Lite/\" " +
                "xmlns:dc=\"http://purl.org/dc/elements/1.1/\" " +
                "xmlns:upnp=\"urn:schemas-upnp-org:metadata-1-0/upnp/\">" +
                "<item id=\"1\" parentID=\"0\" restricted=\"1\">" +
                "<dc:title>${esc(title)}</dc:title><upnp:class>$cls</upnp:class>" +
                "<res protocolInfo=\"http-get:*:$mime:${dlnaFeatures(mime)}\">${esc(url)}</res>" +
                "</item></DIDL-Lite>"
        runCatching { soap(tv, "Stop", "") }
        soap(tv, "SetAVTransportURI",
            "<CurrentURI>${esc(url)}</CurrentURI><CurrentURIMetaData>${esc(didl)}</CurrentURIMetaData>")
        soap(tv, "Play", "<Speed>1</Speed>")
    }

    fun pause(tv: Tv) = soap(tv, "Pause", "")
    fun resume(tv: Tv) = soap(tv, "Play", "<Speed>1</Speed>")
    fun stop(tv: Tv) = soap(tv, "Stop", "")
}
