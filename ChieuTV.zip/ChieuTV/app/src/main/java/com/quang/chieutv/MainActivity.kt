package com.quang.chieutv

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.graphics.Typeface
import android.net.Uri
import android.net.wifi.WifiManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.OpenableColumns
import android.view.Gravity
import android.view.View
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.view.ViewGroup.LayoutParams.WRAP_CONTENT
import android.widget.*
import java.io.File
import java.net.Inet4Address
import java.net.NetworkInterface

class MainActivity : Activity() {

    private val port = 8765
    private lateinit var server: MediaServer
    private val ui = Handler(Looper.getMainLooper())

    private lateinit var status: TextView
    private lateinit var tvSpinner: Spinner
    private lateinit var tvAdapter: ArrayAdapter<Tv>
    private lateinit var autoBox: CheckBox

    private var images = listOf<Uri>()
    private var index = 0
    private var counter = 0

    private val autoNext = object : Runnable {
        override fun run() {
            if (autoBox.isChecked && images.size > 1) {
                showImage((index + 1) % images.size)
                ui.postDelayed(this, 6000)
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        server = MediaServer(applicationContext, port)
        try { server.start(30000, false) } catch (e: Exception) { }
        buildUi()
        loadSavedTv()
        handleShare(intent)
        if (tvAdapter.isEmpty) findTvs()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handleShare(intent)
    }

    override fun onDestroy() {
        ui.removeCallbacksAndMessages(null)
        server.stop()
        super.onDestroy()
    }

    // ---------------- Giao diện ----------------

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun bigButton(text: String, onClick: () -> Unit) = Button(this).apply {
        this.text = text
        textSize = 18f
        isAllCaps = false
        setOnClickListener { onClick() }
    }

    private fun row(vararg views: View) = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        views.forEach { addView(it, LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f)) }
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(16), dp(16), dp(16))
        }
        root.addView(TextView(this).apply {
            text = "Chiếu ảnh & video lên TV"
            textSize = 22f
            setTypeface(typeface, Typeface.BOLD)
            gravity = Gravity.CENTER
        })
        status = TextView(this).apply {
            textSize = 16f
            setPadding(0, dp(12), 0, dp(12))
            text = "Điện thoại và TV cần chung một mạng Wi-Fi."
        }
        root.addView(status)

        root.addView(TextView(this).apply { text = "TV:"; textSize = 16f })
        tvAdapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, mutableListOf())
        tvSpinner = Spinner(this).apply { adapter = tvAdapter }
        root.addView(tvSpinner)
        root.addView(bigButton("🔍  Tìm TV") { findTvs() })

        root.addView(space())
        root.addView(row(
            bigButton("🖼  Chọn ảnh") { pick("image/*", REQ_IMAGE, true) },
            bigButton("🎬  Chọn video") { pick("video/*", REQ_VIDEO, false) }
        ))
        root.addView(row(
            bigButton("◀  Ảnh trước") { if (images.isNotEmpty()) showImage((index - 1 + images.size) % images.size) },
            bigButton("Ảnh tiếp  ▶") { if (images.isNotEmpty()) showImage((index + 1) % images.size) }
        ))
        autoBox = CheckBox(this).apply {
            text = "Tự chuyển ảnh mỗi 6 giây"
            textSize = 16f
            setOnCheckedChangeListener { _, on ->
                ui.removeCallbacks(autoNext)
                if (on) ui.postDelayed(autoNext, 6000)
            }
        }
        root.addView(autoBox)

        root.addView(space())
        root.addView(row(
            bigButton("⏸ Dừng tạm") { tvAction("Đã tạm dừng") { Dlna.pause(it) } },
            bigButton("▶ Phát") { tvAction("Đang phát") { Dlna.resume(it) } },
            bigButton("⏹ Tắt") {
                autoBox.isChecked = false
                tvAction("Đã tắt trình chiếu") { Dlna.stop(it) }
            }
        ))

        setContentView(ScrollView(this).apply { addView(root, MATCH_PARENT, WRAP_CONTENT) })
    }

    private fun space() = View(this).apply { minimumHeight = dp(16) }

    private fun say(msg: String) { ui.post { status.text = msg } }

    // ---------------- Tìm TV ----------------

    private fun findTvs() {
        say("Đang tìm TV trong mạng Wi-Fi…")
        Thread {
            val wifi = applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
            val lock = wifi.createMulticastLock("chieutv").apply { setReferenceCounted(false); acquire() }
            val found = try { Dlna.discover() } catch (e: Exception) { emptyList() } finally { lock.release() }
            ui.post {
                val keep = selectedTv()
                tvAdapter.clear()
                tvAdapter.addAll(found)
                if (found.isEmpty()) {
                    keep?.let { tvAdapter.add(it) }
                    status.text = "Không thấy TV. Anh kiểm tra: TV đang bật, cùng Wi-Fi, " +
                            "và trên TV đã bật 'Chia sẻ màn hình / LG Connect Apps'."
                } else {
                    val lg = found.indexOfFirst { it.name.contains("LG", true) || it.name.contains("webOS", true) }
                    tvSpinner.setSelection(if (lg >= 0) lg else 0)
                    saveTv(found[if (lg >= 0) lg else 0])
                    status.text = "Đã tìm thấy ${found.size} thiết bị. Chọn ảnh hoặc video để chiếu."
                }
            }
        }.start()
    }

    private fun selectedTv(): Tv? = tvSpinner.selectedItem as? Tv

    private fun saveTv(tv: Tv) = getSharedPreferences("tv", MODE_PRIVATE).edit()
        .putString("name", tv.name).putString("url", tv.controlUrl).apply()

    private fun loadSavedTv() {
        val p = getSharedPreferences("tv", MODE_PRIVATE)
        val url = p.getString("url", null) ?: return
        tvAdapter.add(Tv(p.getString("name", "TV") ?: "TV", url))
    }

    private fun tvAction(done: String, action: (Tv) -> Unit) {
        val tv = selectedTv() ?: return say("Chưa có TV. Bấm 'Tìm TV' trước nhé.")
        Thread {
            try { action(tv); say(done) } catch (e: Exception) { say("Lỗi: ${e.message}") }
        }.start()
    }

    // ---------------- Chọn file ----------------

    private fun pick(type: String, req: Int, multiple: Boolean) {
        val i = Intent(Intent.ACTION_GET_CONTENT).apply {
            this.type = type
            addCategory(Intent.CATEGORY_OPENABLE)
            putExtra(Intent.EXTRA_ALLOW_MULTIPLE, multiple)
        }
        startActivityForResult(Intent.createChooser(i, "Chọn file"), req)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != RESULT_OK || data == null) return
        val uris = mutableListOf<Uri>()
        data.clipData?.let { c -> for (i in 0 until c.itemCount) uris.add(c.getItemAt(i).uri) }
        if (uris.isEmpty()) data.data?.let { uris.add(it) }
        if (uris.isEmpty()) return
        when (requestCode) {
            REQ_IMAGE -> { images = uris; showImage(0) }
            REQ_VIDEO -> { autoBox.isChecked = false; showVideo(uris[0]) }
        }
    }

    @Suppress("DEPRECATION")
    private fun handleShare(intent: Intent?) {
        intent ?: return
        val uris = when (intent.action) {
            Intent.ACTION_SEND -> listOfNotNull(intent.getParcelableExtra<Uri>(Intent.EXTRA_STREAM))
            Intent.ACTION_SEND_MULTIPLE ->
                intent.getParcelableArrayListExtra<Uri>(Intent.EXTRA_STREAM) ?: emptyList()
            else -> emptyList()
        }
        if (uris.isEmpty()) return
        val mime = contentResolver.getType(uris[0]) ?: intent.type ?: ""
        if (mime.startsWith("video")) showVideo(uris[0]) else { images = uris; showImage(0) }
    }

    // ---------------- Chiếu ----------------

    private fun showImage(i: Int) {
        index = i
        val tv = selectedTv() ?: return say("Chưa có TV. Bấm 'Tìm TV' trước nhé.")
        val uri = images[i]
        say("Đang gửi ảnh ${i + 1}/${images.size}…")
        Thread {
            try {
                // Đổi ảnh sang JPEG gọn nhẹ, xoay đúng chiều — TV LG hiển thị nhanh và không lỗi định dạng
                val jpg = toTvJpeg(uri)
                send(tv, Uri.fromFile(jpg), "image/jpeg", "jpg", nameOf(uri))
                say("Đang chiếu ảnh ${i + 1}/${images.size}: ${nameOf(uri)}")
            } catch (e: Exception) {
                say("Lỗi khi chiếu ảnh: ${e.message}")
            }
        }.start()
    }

    private fun showVideo(uri: Uri) {
        val tv = selectedTv() ?: return say("Chưa có TV. Bấm 'Tìm TV' trước nhé.")
        say("Đang gửi video…")
        Thread {
            try {
                val mime = contentResolver.getType(uri) ?: "video/mp4"
                val ext = when (mime) {
                    "video/x-matroska" -> "mkv"; "video/avi", "video/x-msvideo" -> "avi"
                    "video/3gpp" -> "3gp"; "video/webm" -> "webm"; else -> "mp4"
                }
                send(tv, uri, mime, ext, nameOf(uri))
                say("Đang chiếu video: ${nameOf(uri)}\nĐể điện thoại mở app và giữ Wi-Fi trong lúc xem.")
            } catch (e: Exception) {
                say("Lỗi khi chiếu video: ${e.message}")
            }
        }.start()
    }

    private fun send(tv: Tv, uri: Uri, mime: String, ext: String, title: String) {
        val ip = localIp() ?: throw RuntimeException("Điện thoại chưa kết nối Wi-Fi")
        server.currentUri = uri
        server.currentMime = mime
        counter++
        val url = "http://$ip:$port/media/$counter.$ext"
        Dlna.play(tv, url, mime, title)
    }

    private fun toTvJpeg(uri: Uri): File {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
        var sample = 1
        while (bounds.outWidth / (sample * 2) >= 1920 || bounds.outHeight / (sample * 2) >= 1920) sample *= 2
        val opts = BitmapFactory.Options().apply { inSampleSize = sample }
        var bmp = contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
            ?: throw RuntimeException("Không đọc được ảnh này")

        val rotate = orientation(uri)
        val scale = minOf(1f, 1920f / maxOf(bmp.width, bmp.height))
        if (rotate != 0 || scale < 1f) {
            val m = Matrix().apply { postScale(scale, scale); postRotate(rotate.toFloat()) }
            val out = Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, m, true)
            if (out != bmp) bmp.recycle()
            bmp = out
        }
        val f = File(cacheDir, "tv_${counter % 3}.jpg")
        f.outputStream().use { bmp.compress(Bitmap.CompressFormat.JPEG, 90, it) }
        bmp.recycle()
        return f
    }

    private fun orientation(uri: Uri): Int {
        if (Build.VERSION.SDK_INT < 24) return 0
        return try {
            contentResolver.openInputStream(uri)?.use {
                when (android.media.ExifInterface(it).getAttributeInt(
                    android.media.ExifInterface.TAG_ORIENTATION, 1)) {
                    6 -> 90; 3 -> 180; 8 -> 270; else -> 0
                }
            } ?: 0
        } catch (e: Exception) { 0 }
    }

    private fun nameOf(uri: Uri): String = try {
        contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use {
            if (it.moveToFirst()) it.getString(0) else null
        } ?: uri.lastPathSegment ?: "file"
    } catch (e: Exception) { uri.lastPathSegment ?: "file" }

    private fun localIp(): String? {
        val all = NetworkInterface.getNetworkInterfaces()?.toList() ?: return null
        val sorted = all.sortedBy { if (it.name.startsWith("wlan")) 0 else 1 }
        for (ni in sorted) {
            if (!ni.isUp || ni.isLoopback) continue
            for (a in ni.inetAddresses) {
                if (a is Inet4Address && !a.isLoopbackAddress && a.isSiteLocalAddress) return a.hostAddress
            }
        }
        return null
    }

    companion object {
        private const val REQ_IMAGE = 1
        private const val REQ_VIDEO = 2
    }
}
