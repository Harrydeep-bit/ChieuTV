# Chiếu TV — app chiếu ảnh & video lên TV LG

App Android gửi ảnh và video từ điện thoại lên TV LG (webOS) qua Wi-Fi, dùng chuẩn DLNA. Không cần cáp, không cần app trên TV.

## Cách lấy file APK (miễn phí, làm một lần)

1. Vào github.com, đăng ký tài khoản (nếu chưa có).
2. Bấm dấu **+** góc trên → **New repository** → đặt tên `ChieuTV` → **Create repository**.
3. Bấm **uploading an existing file**, kéo toàn bộ nội dung thư mục `ChieuTV` (đã giải nén) vào → **Commit changes**.
   - Lưu ý: thư mục `.github` là thư mục ẩn, nhớ tải cả nó lên (đó là phần tự đóng gói APK).
4. Vào tab **Actions** → chờ khoảng 3–5 phút đến khi hiện dấu ✅.
5. Bấm vào lần chạy đó → kéo xuống mục **Artifacts** → tải `ChieuTV-apk` (file zip, bên trong là `app-debug.apk`).
6. Chép APK vào điện thoại, mở ra cài (cho phép "Cài app không rõ nguồn gốc").

## Cách dùng

1. Bật TV, điện thoại và TV chung một Wi-Fi.
2. Mở app → **Tìm TV** → chọn TV LG trong danh sách (app tự nhớ cho lần sau).
3. **Chọn ảnh** (chọn được nhiều ảnh, có nút trước/tiếp và tự chuyển 6 giây) hoặc **Chọn video**.
4. Cũng có thể vào Thư viện ảnh → **Chia sẻ** → chọn **Chiếu TV**.

Khi xem video, để app mở và điện thoại giữ Wi-Fi — TV tải video trực tiếp từ điện thoại.

## Nếu không thấy TV

- Trên TV: Cài đặt → Mạng → bật **LG Connect Apps** / **Chia sẻ màn hình**.
- Tắt chế độ "Wi-Fi khách / cách ly thiết bị" trên modem nếu có.
- Video nên là MP4 (H.264). Ảnh được app tự đổi sang JPEG Full HD trước khi gửi.
